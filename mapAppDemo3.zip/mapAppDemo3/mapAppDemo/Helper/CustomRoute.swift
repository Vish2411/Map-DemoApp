//
//  CustomRoute.swift
//  mapAppDemo
//
//  Created by iMac on 15/08/22.
//

import Foundation
import MapKit
import CoreLocation

var polylines = [[String:[Any]]]()

//MARK: - PROTOCOL FOR ANNOTATION DETAILS
protocol CustomRouteDelegate {
    func anotationSelect(anotation: MKAnnotation)
}

class CustomRoute:NSObject{
    
    static let shared = CustomRoute()
    
    let formatter: DateComponentsFormatter = {
        let formatter = DateComponentsFormatter()
        formatter.unitsStyle = .full
        formatter.allowedUnits = [.hour, .minute]
        return formatter
    }()
    
    var sourcePin: CustomPin?
    var destinationPin:CustomPin?
    var sourceLocation:CLLocationCoordinate2D?
    var destinationLocation:CLLocationCoordinate2D?
    var multyLocations = [CLLocationCoordinate2D]()
    var annotations = [MKAnnotation]()
    var multyannotation = [MKAnnotation]()
    var mapView:MKMapView?
    var routeColor = UIColor.systemIndigo
    var cPinImage = UIImage(named: "CurrentImage")
    var dPinImage = UIImage(named: "Destinationimage")
    var mpinImage = UIImage(named: "flag")
    var delegate:CustomRouteDelegate?
    var routeNumber:String = "0"
    var multyPIn :[CustomPin]?
    
    
    override init(){
        
    }
    
    // MARK: - THIS METHOD FOR SET MULTY LOCATION PIN
    public func setDataForMPins(msource:[CustomPin], map:MKMapView){
        for multyLocation in msource{
            self.multyLocations.append(multyLocation.coordinate)
        }
        self.multyPIn = msource
        self.mapView = map
        self.multymakepins()
        self.mapView?.delegate = self
    }
    
    // MARK: - THIS METHOD FOR 2 LOCATION DISTANCE GET
    public func setData(source:CustomPin, destination:CustomPin, map:MKMapView , routeColor:UIColor,pinImage:String, routeNumber:String){
        self.sourceLocation = source.coordinate
        self.destinationLocation = destination.coordinate
        self.sourcePin = source
        self.destinationPin = destination
        self.mapView = map
        self.routeColor = routeColor
        self.makepins()
        self.drawPins()
        self.mapView?.delegate = self   
    }
    
    fileprivate func makepins(){
        self.annotations = [self.sourcePin!,self.destinationPin!]
        self.mapView!.addAnnotations(self.annotations)
    }
    
    fileprivate func multymakepins(){
        self.multyannotation = self.multyPIn!
        self.mapView!.addAnnotations(self.multyannotation)
    }
    
    fileprivate func drawPins(){
        
        let sourcePlaceMark = MKPlacemark(coordinate: self.sourceLocation!)
        let destPlaceMArk = MKPlacemark(coordinate: self.destinationLocation!)

        let sourceItem = MKMapItem(placemark: sourcePlaceMark)
        let destItem = MKMapItem(placemark: destPlaceMArk)

        let destinationRequest = MKDirections.Request()
        destinationRequest.source = sourceItem
        destinationRequest.destination = destItem
        destinationRequest.transportType = .automobile
        destinationRequest.requestsAlternateRoutes = true

        let directions = MKDirections(request: destinationRequest)
        directions.calculate { (response, error) in
            guard let directionResponse = response else{
                if let error = error {
                    print("we have error getting directions==\(error.localizedDescription)")
                }
                return
            }

            let route = directionResponse.routes[0]
            print("heloo....heloooo......")
            
            print(route.distance)
            let kmDistance = String(format: "%.2f", route.distance / 1000)
            print("\(kmDistance) Km")
            
            print(route.expectedTravelTime)
            if let result = self.formatter.string(from:route.expectedTravelTime) {
                print(result)
            }
            
            let polyLine = route.polyline
            polyLine.title = self.routeNumber
            
            let circle = MKCircle(center: self.sourceLocation!, radius: 500)
            
            polylines.append(["\(self.routeNumber)": [polyLine, self.routeNumber,self.dPinImage]]) ///what
            
//            self.mapView?.addOverlays([polyLine,circle])
            self.mapView?.addOverlay(polyLine, level: .aboveRoads)
            self.mapView?.addOverlay(circle)
            self.mapView!.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
            
            
        }
    }
}

extension CustomRoute : MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay is MKPolyline {

            let renderer = MKPolylineRenderer(overlay: overlay)
            renderer.strokeColor = .systemBlue
            renderer.lineWidth = 3.0
            return renderer
            
        }
        if overlay is MKCircleRenderer{
            
            let circleRenderer = MKCircleRenderer(overlay: overlay)
                circleRenderer.strokeColor = UIColor.red
                circleRenderer.lineWidth = 1.0
                return circleRenderer
            
        }
        return MKOverlayRenderer()
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let Identifier = "Pin"
        let annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: Identifier) ?? MKAnnotationView(annotation: annotation, reuseIdentifier: Identifier)

        if annotation is MKUserLocation {
            return nil
        } else if annotation is CustomPin {
        
            var isMultyPin = false
            if let MultyPins = multyPIn{
                for multyPins in MultyPins{
                    if annotation.title == multyPins.title{
                        annotationView.image =  UIImage(named: "flag")
                        isMultyPin = true
                        break
                    }
                    
                }
            }
            
            if !isMultyPin {
                
                print("Aaaa \(annotation.title)")
                if annotation.title == sourcePin?.title{
                    print("Aaaaaaa \(annotation.title)")
                    annotationView.image =  UIImage(named: "CurrentImage")
                }else{
                    annotationView.image =  UIImage(named: "Destinationimage")
                }
            }

            let btn = UIButton()
            btn.setTitle("", for: .normal)
            annotationView.addSubview(btn)
            btn.frame = annotationView.bounds
            btn.addAction(UIAction(handler: { action in
                self.delegate?.anotationSelect(anotation: annotation)
            }), for: .touchUpInside)

            annotationView.canShowCallout = true

            return annotationView
        } else {
            return nil
        }
        
    }
    
    func mapView(_ mapView: MKMapView, didAdd views: [MKAnnotationView]) {
        views.forEach { view in
            view.isSelected = true
        }
    }
}

extension MKMapView {
    
    func fitAllAnnotations() {
        var zoomRect = MKMapRect.null;
        for annotation in annotations {
            let annotationPoint = MKMapPoint(annotation.coordinate)
            let pointRect = MKMapRect(x: annotationPoint.x, y: annotationPoint.y, width: 0.1, height: 0.1);
            zoomRect = zoomRect.union(pointRect);
        }
        setVisibleMapRect(zoomRect, edgePadding: UIEdgeInsets(top: 50, left: 50, bottom: 50, right: 50), animated: true)
    }
}
