//
//  CustomPin.swift
//  mapAppDemo
//
//  Created by iMac on 15/08/22.
//

import Foundation
import MapKit

class CustomPin:NSObject ,MKAnnotation{
    var title: String?
    var subtitle: String?
    var coordinate: CLLocationCoordinate2D

    init(pinTitle:String, pinSubtitle:String, location:CLLocationCoordinate2D){
        self.title = pinTitle
        self.subtitle = pinSubtitle
        self.coordinate = location
    }
}

class CreateCustomPinForLocations{
    
    class func GetPins(sourceTitle:String , sourceSubtitle:String, sourceLoaction:CLLocationCoordinate2D, destinationtitle:String, destinationSubTitle:String, destinationLoaction:CLLocationCoordinate2D) -> (CustomPin,CustomPin){
        
        let sourcePin = CustomPin(pinTitle: sourceTitle, pinSubtitle: sourceSubtitle, location: sourceLoaction)
        let destinationPin = CustomPin(pinTitle: destinationtitle, pinSubtitle: destinationSubTitle, location: destinationLoaction)
        return (sourcePin,destinationPin)
    }
    
    class func MakeMultyCutomPin(locationTitle: String, locationSubTitle:String, multyLocation:CLLocationCoordinate2D) -> CustomPin {
        
        let mLocation = CustomPin(pinTitle: locationTitle, pinSubtitle: locationSubTitle, location: multyLocation)
        return mLocation
    }
}
