//
//  ViewController.swift
//  mapAppDemo
//
//  Created by iMac on 12/08/22.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, MKMapViewDelegate{

    //MARK: - OUTLET
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var enterPlace: UITextField!
    @IBOutlet weak var btnGetDirection: UIButton!
    
    //MARK: - VARIABLE
    fileprivate let locationManager = CLLocationManager()
    var routeColor = UIColor.systemIndigo
    var annotaions = [MKAnnotation]()
    
    var sourceLocation:CLLocationCoordinate2D?
    var destinationLoaction:CLLocationCoordinate2D?
    var getDestination:String?
    var cPinImage = "CurrentImage"
    
    //MARK: - LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupLocationManager()
        DispatchQueue.main.asyncAfter(deadline: .now()+1) { [self] in
            setUpMapView()
            setMultyLOcationPin()
            
            mapView.showAnnotations(annotaions, animated: true)
        }
    }
    
    //MARK: - SET UP MAP VIEW
    func setUpMapView(){
        mapView.delegate = self
        mapView.isPitchEnabled = true
        mapView.mapType = .standard
        mapView.isScrollEnabled = true
        mapView.isZoomEnabled = true
        mapView.showsTraffic = true
        mapView.transform = .identity
    }
    
    //MARK: - SET UP LOCATION MANAGER
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    @IBAction func btnDirectionAction(_ sender: Any) {
        getDestinationPlace()
    }
    
    func setMultyLOcationPin(){
        
        let multyLocation = [
                    CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "London", locationSubTitle: "1", multyLocation: CLLocationCoordinate2D.init(latitude: 51.5072, longitude: 0.1276)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "USA", locationSubTitle: "2", multyLocation: CLLocationCoordinate2D.init(latitude: 37.0902, longitude: 95.7129)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "Berlin", locationSubTitle: "3", multyLocation: CLLocationCoordinate2D.init(latitude: 52.5200, longitude: 13.4050)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "rome", locationSubTitle: "4", multyLocation: CLLocationCoordinate2D.init(latitude: 52.5200, longitude: 2.2426)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "Dubai", locationSubTitle: "5", multyLocation: CLLocationCoordinate2D.init(latitude: 25.2048, longitude: 55.2708)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "Moscow", locationSubTitle: "6", multyLocation: CLLocationCoordinate2D.init(latitude: 55.7558, longitude: 37.6173)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "Europe", locationSubTitle: "7", multyLocation: CLLocationCoordinate2D.init(latitude: 54.5260, longitude: 15.2551)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "Paris", locationSubTitle: "8", multyLocation: CLLocationCoordinate2D.init(latitude: 48.8566, longitude: 2.3522)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "England", locationSubTitle: "9", multyLocation: CLLocationCoordinate2D.init(latitude: 52.3555, longitude: 1.1743)),
                      CreateCustomPinForLocations.MakeMultyCutomPin(locationTitle: "Amsterdam", locationSubTitle: "10", multyLocation: CLLocationCoordinate2D.init(latitude: 52.3676, longitude: 4.9041))
        ]
        
        CustomRoute.shared.setDataForMPins(msource: multyLocation, map: self.mapView)
        
    }
    
    func getDestinationPlace(){
        if enterPlace.text != ""{
            self.getDestination = enterPlace.text
            let geoCoder = CLGeocoder()
            geoCoder.geocodeAddressString(enterPlace.text!) { (placeMark,error) in

                guard let placeMark = placeMark,let location = placeMark.first?.location
                else{
                    let Alert = UIAlertController.init(title: "Not Found!", message: "Your Enter Location Name is Not Found", preferredStyle: .alert)
                    let Ok = UIAlertAction.init(title: "Ok", style: .default, handler: nil)
                    Alert.addAction(Ok)
                    self.present(Alert, animated: true, completion: nil)
                    
                    print("No location found")
                    return
                }
                
                print(location)
                
                if location != nil{
                    self.destinationLoaction = location.coordinate
                }else{
                    print("Destination Location Is not Found !!")
                }
                self.AddLocation()
                
            }
        }else{
            let Alert = UIAlertController.init(title: "Alert", message: "Enter Any Destination", preferredStyle: .alert)
            let ok = UIAlertAction.init(title: "ok", style: .default, handler: nil)
            Alert.addAction(ok)
            self.present(Alert, animated: true, completion: nil)
        }
    }
}

extension ViewController : CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations)
        
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(locationManager.location!.coordinate.latitude, locationManager.location!.coordinate.longitude)
        
        //GET CURRENT LOCATION TO SOURCELOCATION VARIABLE
        sourceLocation = myAnnotation.coordinate
        myAnnotation.title = "Current location"
        myAnnotation.accessibilityContainerType = .landmark
        mapView.addAnnotation(myAnnotation)
    }
}
    
extension ViewController : CustomRouteDelegate{
    
    func anotationSelect(anotation: MKAnnotation) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SViewController") as! SViewController
        vc.annotation = anotation
        vc.height = 160
        vc.topCornerRadius = 30
        vc.presentDuration = 0.15
        vc.dismissDuration = 0.15
        vc.getDestinationFromVC1 = getDestination!
        self.present(vc, animated: true, completion: nil)
    }
    
    func AddLocation(){
        //Get Current Location Pin
        let cLocation = CreateCustomPinForLocations.GetPins(sourceTitle: "Current Location", sourceSubtitle: "Office", sourceLoaction: self.sourceLocation!, destinationtitle: "Destination Location", destinationSubTitle: "\(getDestination!)", destinationLoaction: self.destinationLoaction!)
        
        //add location1 Route
        CustomRoute.shared.setData(source: cLocation.0, destination: cLocation.1, map: self.mapView, routeColor: .red, pinImage: "Clocation", routeNumber: "1")
    }
}
    
