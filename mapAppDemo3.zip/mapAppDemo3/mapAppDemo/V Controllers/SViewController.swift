//
//  SViewController.swift
//  mapAppDemo
//
//  Created by iMac on 15/08/22.
//

import UIKit
import MapKit
import BottomPopup

class SViewController: BottomPopupViewController {

    //MARK: - OUTLET
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    
    //MARK: - VARIABLE FOR GET DATA
    var height: CGFloat?
    var topCornerRadius: CGFloat?
    var presentDuration: Double?
    var dismissDuration: Double?
    var shouldDismissInteractivelty: Bool?
    var getDestinationFromVC1:String?
    
    var annotation: MKAnnotation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setupUI()
    }
    
    override func viewDidLayoutSubviews() {
        DispatchQueue.main.async {
            self.view.roundCorners(corners: [.topLeft,.topRight], radius: self.topCornerRadius ?? 30)
        }
    }
    
//     MARK: - BottomPopupAttributesDelegate Variables
    override var popupHeight: CGFloat { height ?? 300.0 }
    override var popupTopCornerRadius: CGFloat { topCornerRadius ?? 10.0 }
    override var popupPresentDuration: Double { presentDuration ?? 1.0 }
    override var popupDismissDuration: Double { dismissDuration ?? 1.0 }
    override var popupShouldDismissInteractivelty: Bool { shouldDismissInteractivelty ?? true }
    override var popupDimmingViewAlpha: CGFloat { BottomPopupConstants.kDimmingViewDefaultAlphaValue }

    func setupUI() {
        if let annotaion = self.annotation {
            self.label1.text = "Place Name: \(String(describing: annotaion.title! ?? ""))"
            self.label2.text = "Latitude: \(annotaion.coordinate.latitude)"
            self.label3.text = "Longitude: \(annotaion.coordinate.longitude)"
            
//            self.label3.text = "Place Name: \(String(describing: annotaion.title! ?? ""))"
        }
    }
}

extension UIView {

    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
}
